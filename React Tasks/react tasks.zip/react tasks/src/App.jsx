import './App.css'
import Data from './Data'

function App() {
  return (
    <>
      <Data/>
    </>
  )
}

export default App
