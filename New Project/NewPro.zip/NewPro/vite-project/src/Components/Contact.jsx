import MainContent from "./MainContent";

export default function Contact(){
    return(
        <>
       <MainContent head="contact us" btnText="about" color="purple" fontFamily="arial" paraColor="yellow"/>
        </>
    )
}