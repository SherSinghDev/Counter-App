import MainContent from "./MainContent";

export default function Home(){
    return(
        <>
        <MainContent  head="Home Page" btnText="contact" color="greenyellow" fontFamily="cursive" paraColor="cyan"/>
        </>
    )
}