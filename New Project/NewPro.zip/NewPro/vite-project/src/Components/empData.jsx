import img1 from "../assets/img1.jpg";
import img2 from "../assets/img2.avif";
import img3 from "../assets/img3.jpg";
import img4 from "../assets/img4.jpg";
import img5 from "../assets/img5.jpg";
import img6 from "../assets/img6.webp";
let data  = [
    {
        name:"Tanuj",
        img: img1
    },
    {
        name:"Taryan",
        img: img2
    },
    {
        name:"Samir",
        img: img3
    },
    {
        name:"Priyanka",
        img: img4
    },
    {
        name:"Vandana",
        img: img5
    },
    {
        name:"Deepak",
        img: img6
    }
    

]

export default data;