import MainContent from "./MainContent";

export default function About(){
    return(
        <>
        <MainContent head="About Page" btnText="services" color="tomato" fontFamily="sans-serif" paraColor="tomato"/>
        </>
    )
}