import Card from "./Card";
import data from "./empData";
export default function Services(){
    console.log(data)
    return(
        <>
        <Card/>
        </>
    )
}