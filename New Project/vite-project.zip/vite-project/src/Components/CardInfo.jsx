import img1 from "../assets/pngwing1.png";
import img2 from "../assets/pngwing2.png";
import img3 from "../assets/pngwing3.png";
import img4 from "../assets/pngwing4.png";
import img5 from "../assets/pngwing5.png";
import img6 from "../assets/pngwing6.png";
let fullData = [
    {
        imgSrc: img1,
        title:"Our Network",
    },
    {
        imgSrc: img2,
        title:"Our Skills"
    },
    {
        imgSrc: img3,
        title:"Our technologies"
    },
    {
        imgSrc: img4,
        title:"Hard Workers"
    },
    {
        imgSrc: img5,
        title:"Secure Work"

    },
    {
        imgSrc: img6,
        title:"New Technologies"
    }
    
]
export default fullData;