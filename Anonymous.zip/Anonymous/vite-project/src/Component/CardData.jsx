let cardData = [
    {
        icon:"fa-solid fa-mobile-screen-button",
        cardTitle:"Mobile Developement"
    },
    {
        icon:"fa-solid fa-laptop-code",
        cardTitle:"Web Development"
    },
    {
        icon:"fa-solid fa-palette",
        cardTitle:"Web Design"
    },
    {
        icon:"fa-solid fa-code",
        cardTitle:"Web Applications"
    },
    {
        icon:"fa-solid fa-magnifying-glass",
        cardTitle:"SEO Search"
    },
    {
        icon:"fa-solid fa-bullhorn",
        cardTitle:"New Technologies"
    }
]

export default cardData;